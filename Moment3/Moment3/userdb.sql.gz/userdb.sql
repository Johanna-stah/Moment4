-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 25, 2021 at 10:28 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `userdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
CREATE TABLE `posts` (
  `id` int(4) NOT NULL,
  `content` text NOT NULL,
  `title` varchar(30) NOT NULL,
  `postdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `username` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `content`, `title`, `postdate`, `username`) VALUES
(17, '<blockquote>\r\n<p>&quot;Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit...&quot;</p>\r\n\r\n<p>&quot;There is no one who loves pain itself, who seeks after it and wants to have it, simply because it is pain...&quot;</p>\r\n</blockquote>\r\n\r\n<hr />\r\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus gravida nec risus nec venenatis. Integer lorem lorem, interdum a sem vitae, pellentesque mattis justo. Morbi ullamcorper justo elit, non tempor ipsum blandit vitae. Vestibulum mollis molestie tellus, nec tincidunt velit eleifend non. Cras elementum ultrices augue, vel consequat eros auctor ut. Duis pulvinar facilisis lacinia. Vivamus vulputate dui at erat ultrices, quis scelerisque lacus consectetur. In nec purus dolor. Donec metus diam, convallis in faucibus vel, malesuada luctus urna. Cras ac ante ut eros gravida consectetur suscipit ac ex. Nulla non nulla porta nisi porttitor viverra. Proin facilisis consequat urna ac semper. Nam nulla diam, venenatis vestibulum sodales vitae, iaculis quis arcu. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.</p>\r\n', 'Titel 1', '2021-03-23 10:33:11', 'johanna'),
(18, '<p>Nam mattis elit vitae nibh hendrerit, ut ullamcorper quam ornare. Quisque id eros odio. Vestibulum porttitor ultrices lacinia. Vivamus a placerat orci. Sed quis sagittis lorem, quis rutrum odio. Morbi elementum, elit eget facilisis vulputate, dolor ligula fringilla tellus, vitae malesuada quam ligula et velit. Donec quis elementum massa.</p>\r\n', 'Titel 2', '2021-03-23 10:33:46', 'johanna'),
(19, '<p>Fusce sed feugiat velit, sit amet viverra turpis. Suspendisse sollicitudin diam eu condimentum blandit. Maecenas lectus enim, finibus ac ligula vel, iaculis posuere est. Cras dapibus nulla a justo dignissim, eget sollicitudin eros tincidunt. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Nullam sed neque venenatis, blandit ante vitae, vestibulum ante. Morbi fringilla sem id nunc elementum, a ullamcorper risus cursus. In scelerisque, odio sed tincidunt aliquam, ligula ante euismod metus, et semper nulla nibh in mauris. Integer congue consectetur nibh vitae elementum. Aenean ullamcorper nibh vitae lorem congue congue. Nulla fringilla pretium sapien. Sed vitae nunc ac felis blandit tincidunt ut et ligula. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec sit amet nibh vel nulla mollis interdum in sed purus. Phasellus eu lectus blandit, mattis metus aliquet, viverra mauris. Nam magna ante, consectetur sed tellus in, aliquet congue enim.</p>\r\n', 'Titel 3', '2021-03-23 10:34:34', 'johanna'),
(20, '<p>Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Nulla mollis vehicula convallis. Duis varius interdum augue, non posuere felis auctor nec. Nulla bibendum egestas aliquet. Vestibulum lobortis, eros vel vestibulum fermentum, neque ligula laoreet tellus, vel accumsan justo quam egestas nisi. Nulla feugiat leo eu metus aliquam tincidunt. Integer vel ultrices elit. Ut et erat at tellus pellentesque lacinia vel a purus. Nunc at nulla quis magna sodales ultrices at eget lacus.</p>\r\n', 'Titel 4', '2021-03-23 11:03:52', 'johanna'),
(21, '<h3>Mauris convallis turpis ac neque finibus,<s> eu rhoncus massa bibendum.</s></h3>\r\n\r\n<p>Duis dictum consectetur viverra. Fusce auctor, enim in scelerisque pellentesque, neque nisi ullamcorper tortor, vitae tristique lacus felis at sem. Ut at ligula nisi. <strong>Cras</strong> in tellus malesuada, pretium est non, aliquam metus. Praesent vulputate ornare ipsum a fringilla. Suspendisse potenti. Phasellus in sagittis lacus.<em> Nulla maximus dignissim ante at rutrum.</em> Quisque ipsum neque, vehicula et purus vel, porta ullamcorper mi.</p>\r\n', 'Titel 5', '2021-03-23 11:34:17', 'johanna'),
(22, '<div style=\"background:#eeeeee;border:1px solid #cccccc;padding:5px 10px;\">Maecenas commodo massa rutrum sodales finibus. Nam aliquet nisi non malesuada dignissim. Donec facilisis suscipit mi, ac fringilla nulla pellentesque a. Pellentesque vehicula erat sed hendrerit facilisis. Curabitur quis facilisis ligula, a efficitur justo. Pellentesque consectetur egestas lacus, a tincidunt tellus convallis ut. Aliquam auctor dolor non odio molestie, in cursus libero euismod.</div>\r\n\r\n<p>Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Nulla mollis vehicula convallis. Duis varius interdum augue, non posuere felis auctor nec. Nulla bibendum egestas aliquet. Vestibulum lobortis, eros vel vestibulum fermentum, neque ligula laoreet tellus, vel accumsan justo quam egestas nisi. Nulla feugiat leo eu metus aliquam tincidunt. Integer vel ultrices elit. Ut et erat at tellus pellentesque lacinia vel a purus. Nunc at nulla quis magna sodales ultrices at eget lacus.</p>\r\n', 'Titel 6', '2021-03-24 11:39:13', 'johanna'),
(25, '<div style=\"background:#eeeeee;border:1px solid #cccccc;padding:5px 10px;\">Sed vitae nunc ac felis blandit tincidunt ut et ligula. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec sit amet nibh vel nulla mollis interdum in sed purus. Phasellus eu lectus blandit, mattis metus aliquet, viverra mauris. Nam magna ante, consectetur sed tellus in, aliquet congue enim.</div>\r\n\r\n<p><small>Sed vitae nunc ac felis blandit tincidunt ut et ligula. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec sit amet nibh vel nulla mollis interdum in sed purus. Phasellus eu lectus blandit, mattis metus aliquet, viverra mauris. Nam magna ante, consectetur sed tellus in, aliquet congue enim.</small></p>\r\n\r\n<h3><ins>Sed vitae nunc ac felis blandit tincidunt ut et ligula. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec sit amet nibh vel nulla mollis interdum in sed purus. Phasellus eu lectus blandit, mattis metus aliquet, viverra mauris. Nam magna ante, consectetur sed tellus in, aliquet congue enim.</ins></h3>\r\n', 'Titel 7', '2021-03-24 15:32:34', 'Katt');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `name` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `created_at`, `name`) VALUES
(2, 'johanna', '$2y$10$ZZGq9oyE6E/qQZ.T9mRSluFytu7ENO91TCdU8t5LR51yJcP0aNQ1q', '2021-03-23 12:23:56', NULL),
(3, 'Katt', '$2y$10$CdID8NOvhm7/ytmipuP8n.OJpvUtNf/mAhTPUOSS3HQt2cSvUmmt6', '2021-03-24 13:05:44', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username` (`username`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
